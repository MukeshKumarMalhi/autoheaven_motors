@extends('layouts.a_app')

@section('content')
    <!-- Page Content -->
    <div id="page-content-wrapper">

        <div class="container-fluid py-3">
          <h3>Admin Dashboard</h3>
        </div>
    </div>
@endsection
