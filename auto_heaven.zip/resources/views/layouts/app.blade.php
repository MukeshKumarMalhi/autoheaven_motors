@include('website.library')

@include('website.header')
@include('website.sub_header')

@yield('content')

@include('website.footer')




</body>
</html>
