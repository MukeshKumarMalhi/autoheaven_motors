<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SellYourVehicle extends Model
{
    //
}
