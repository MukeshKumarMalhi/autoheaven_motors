<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InteriorFeature extends Model
{
    //
}
