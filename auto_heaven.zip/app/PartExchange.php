<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PartExchange extends Model
{
    //
}
