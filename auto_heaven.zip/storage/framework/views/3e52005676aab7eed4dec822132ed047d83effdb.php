<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <head>
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
      <meta name="userId" content="<?php echo e(Auth::check() ? Auth::user()->id : ''); ?>">

      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta content="telephone=no" name="format-detection">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>Autoheaven Motors | Admin Login</title>

      <!-- Latest compiled and minified CSS -->
      <link rel="shortcut icon" href="<?php echo e(asset('admin_asset/images/fav-icon-32.ico')); ?>" type="image/x-icon" />
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700|Montserrat:300,400,500,600,700,800&amp;subset=latin-ext" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.12/css/select2.min.css">
      <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
      <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.1/css/swiper.min.css">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_asset/css/fontawesome.min.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_asset/css/datepicker.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_asset/css/daterangepicker.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_asset/css/custom.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('admin_asset/css/bootstrap-timepicker.min.css')); ?>"  type="text/css" />
      <script type="text/javascript" src="<?php echo e(asset('admin_asset/js/jquery.min.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(asset('admin_asset/js/app.js')); ?>"></script>
      <!-- <script type="text/javascript" src="<?php echo e(asset('admin_asset/js/jquery-3.4.1.slim.min.js')); ?>"></script> -->
      <script type="text/javascript" src="<?php echo e(asset('admin_asset/js/moment.min.js')); ?>"></script>
      <!-- <script type="text/javascript" src="<?php echo e(asset('js/popper.min.js')); ?>"></script> -->
      <script type="text/javascript" src="<?php echo e(asset('admin_asset/js/datepicker.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(asset('admin_asset/js/bootstrap.bundle.min.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(asset('admin_asset/js/daterangepicker.min.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(asset('admin_asset/js/bootstrap-timepicker.min.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(asset('admin_asset/js/custom.js')); ?>"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.1/js/swiper.min.js"></script>
  </head>

  <body class="bg-dark-blue">
    <div class="container section-login">
        <div class="row vh-100 align-items-sm-center">
            <div class="col-sm-6 offset-sm-3">

                <div class="text-light link-light">
                    <div class="form-group">
                        <h2><strong>Welcome Admin</strong></h2>
                    </div>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                      <?php if(isset($error)): ?>
                        <p class="alert alert-danger" style="color: #F00;"><?php echo $error; ?></p>
                      <?php endif; ?>
                      <?php echo csrf_field(); ?>
                      <div class="form-group">
                          <input  id="username" type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus placeholder="Username">
                          <?php if($errors->has('username')): ?>
                            <div class="error" style="color: #dc3545;"><?php echo e($errors->first('username')); ?></div>
                          <?php endif; ?>
                      </div>
                      <div class="form-group">
                          <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Password">
                          <?php if($errors->has('password')): ?>
                            <div class="error" style="color: #dc3545;"><?php echo e($errors->first('password')); ?></div>
                          <?php endif; ?>
                      </div>
                    <div class="form-group clearfix small d-table w-100">
                        <!-- <div class="form-check custom-checkbox d-table-cell align-top">
                            <input class="form-check-input" type="checkbox" value="" name="remember" id="remember"<?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="remembercheck">Remember Me</label>
                        </div>
                        <div class="d-table-cell text-right align-top"><a href="#" data-toggle="modal" data-target="#forget-password">Forgot password?</a></div> -->
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-blue" style="border-radius: 5px;">Log in</button>
                    </div>
                    <?php if(Session::has('error')): ?>
                      <p class="alert alert-danger" style="color: #F00;"><?php echo e(Session::get('error')); ?></p>
                    <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
  <style media="screen">
    .form-control{
      border-radius: 5px;
    }
  </style>
  </body>
</html>
<?php /**PATH C:\wamp64\www\auto_heaven\resources\views/auth/login.blade.php ENDPATH**/ ?>