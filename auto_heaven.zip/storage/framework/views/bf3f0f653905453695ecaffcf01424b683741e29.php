<?php echo $__env->make('website.library', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>

<?php if(!isset($user)): ?>
  <?php echo $__env->make('website.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if(isset($user)): ?>
  <?php echo $__env->make('website.sub_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<!-- Page contents -->
  <div class="bg-grey hw-height">
    <?php echo $__env->yieldContent('content'); ?>
  </div>
<?php echo $__env->make('website.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH C:\wamp64\www\auto_heaven\resources\views\website\master.blade.php ENDPATH**/ ?>