<!-- Sidebar-left -->
<div id="sidebar-wrapper" class="link-light p-3">
    <!-- Menu Button -->
    <ul class="list-unstyled fa-ul co-menu ml-4 co-menu">
        <li class="active"><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa-li fas fa-circle text-light"></i>Dashboard</a></li>
        <li class="active"><a href="<?php echo e(url('admin/view_categories')); ?>"><i class="fa-li fas fa-circle text-light"></i>Categories</a></li>
        <li class="active"><a href="<?php echo e(url('admin/view_cars')); ?>"><i class="fa-li fas fa-circle text-light"></i>Cars</a></li>
    </ul>
</div>
<?php /**PATH C:\wamp64\www\auto_heaven\resources\views\admins\sidebar.blade.php ENDPATH**/ ?>