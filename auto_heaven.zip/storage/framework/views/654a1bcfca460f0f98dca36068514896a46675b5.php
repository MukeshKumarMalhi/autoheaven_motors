

<?php $__env->startSection('content'); ?>
    <!-- Page Content -->
    <div id="page-content-wrapper">

        <div class="container-fluid py-3">
          <h3>Admin Dashboard</h3>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.a_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\auto_heaven\resources\views/admins/dashboard.blade.php ENDPATH**/ ?>